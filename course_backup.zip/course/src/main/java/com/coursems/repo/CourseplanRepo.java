package com.coursems.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coursems.model.Courseplan;

@Repository
public interface CourseplanRepo extends JpaRepository<Courseplan, Integer> {

    boolean existsByBatchId(int batchId);

}
	