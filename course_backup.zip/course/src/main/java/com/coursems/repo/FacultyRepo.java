package com.coursems.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coursems.model.Faculty;

@Repository
public interface FacultyRepo extends JpaRepository<Faculty, Integer> {

	
    Optional<Faculty> findByUsername(String username);

}
	