package com.coursems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.coursems.model.Batch;
import com.coursems.service.BatchService;
import com.coursems.service.CourseService;
import com.coursems.service.FacultyService;

import jakarta.validation.Valid;

@Controller
public class BatchController {

	@Autowired
	private BatchService batchService;

	@Autowired
	private CourseService courseService;

	@Autowired
	private FacultyService facultyService;

	@PostMapping("/batches")
	public String saveBatches(Batch batch, Model model, BindingResult result) {
	    if (!courseService.existsById(batch.getCourseId())) {
	        result.rejectValue("courseId", "error.course", "This Course ID does not exist.");
	    }
	    if (!facultyService.existsById(batch.getFacultyId())) {
	        result.rejectValue("facultyId", "error.faculty", "This Faculty ID does not exist.");
	    }
	    
	    // Check if a batch with the same name already exists
	    if (batchService.existsByName(batch.getBatchName())) {
	        result.rejectValue("batchName", "error.batchName", "A batch with this name already exists.");
	    }


	    if (result.hasErrors()) {
	        return "create_batch"; // Return to the form with errors
	    }
	    model.addAttribute("successMessage", "Batch created successfully.");
	    batchService.saveBatch(batch); // Save the batch here
	    return "redirect:/batches"; // Redirect to the batches page
	}


	@GetMapping("/batches")
	public String listBatches(Batch batch, Model model) {
		System.out.println("Inside show batches");
		model.addAttribute("batches", batchService.displayBatches(batch));
		return "batches";
	}

	@GetMapping("batch/new")
	public String showCreateForm(Model model) {
		Batch batch = new Batch();
		model.addAttribute("batch", batch);
		return "create_batch";
	}

	@GetMapping("/batch/update/{batchId}")
	public String showUpdateForm(@PathVariable("batchId") int id, Model model) {
		Batch batch = batchService.find(id);
		model.addAttribute("batch", batch);
		return "update_batch";
	}

	@PostMapping("batches/update")
	public String updateBatch(@Valid Batch batch, BindingResult result) {
		
		if (!courseService.existsById(batch.getCourseId())) {
	        result.rejectValue("courseId", "error.course", "This Course ID does not exist.");
	    }
	    if (!facultyService.existsById(batch.getFacultyId())) {
	        result.rejectValue("facultyId", "error.faculty", "This Faculty ID does not exist.");
	    }
	    if (result.hasErrors()) {
	        return "update_batch"; // Return to the form with errors
	    }
		batchService.updateBatch(batch);
		return "redirect:/batches";
	}

	@GetMapping("/batch/delete/{batchId}")
	public String deleteBatch(@PathVariable("batchId") int id) {
		batchService.deleteBatch(id);
		return "redirect:/batches";
	}
}
