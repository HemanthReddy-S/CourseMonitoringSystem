package com.coursems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.coursems.model.Courseplan;
import com.coursems.service.CourseplanService;

import jakarta.validation.Valid;

@Controller
public class CourseplanController {

    @Autowired
    private CourseplanService cps;
	/*
	 * @PostMapping("/courseplans") public String saveCourseplan(@Valid Courseplan
	 * courseplan, Model model) { System.out.println("Inside save courseplan");
	 * 
	 * cps.saveCourseplan(courseplan); return "redirect:/courseplans"; }
	 */

    @PostMapping("/courseplans")
    public String saveCourseplan(@Valid Courseplan courseplan, BindingResult result, Model model) {
        System.out.println("Inside save courseplan");
        
        boolean batchIdExists = cps.checkIfBatchIdExists(courseplan.getBatchId());
        if (!batchIdExists) {
            // Add a custom error to the BindingResult
            result.rejectValue("batchId", "error.batchId", "Batch ID does not exist.");
            // Or, alternatively, add a custom attribute to the model
            model.addAttribute("batchIdExistsError", true);
            // Redirect back to the form with the error
            return "create_courseplan";
        }
        
        cps.saveCourseplan(courseplan);
        return "redirect:/courseplans";
    }




	@GetMapping("/courseplans")
    public String listCourseplans(Courseplan courseplan, Model model) {
        System.out.println("Inside show courseplans");
        model.addAttribute("courseplans", cps.displayCourseplan(courseplan));
        return "courseplan";
    }

    @GetMapping("/courseplan/new")
    public String showCreateCourseplanForm(Model model) {
        Courseplan courseplan = new Courseplan();
        model.addAttribute("courseplan", courseplan);
        return "create_courseplan";
    }

    @GetMapping("/courseplan/update/{planId}")
    public String showUpdateCourseplanForm(@PathVariable("planId") int id, Model model) {
        Courseplan courseplan = cps.find(id);
        model.addAttribute("courseplan", courseplan);
        return "update_courseplan";
    }

    @PostMapping("/courseplans/update")
    public String updateCourseplan(@Valid Courseplan courseplan, BindingResult result,  Model model) {
    	 boolean batchIdExists = cps.checkIfBatchIdExists(courseplan.getBatchId());
         if (!batchIdExists) {
             // Add a custom error to the BindingResult
             result.rejectValue("batchId", "error.batchId", "Batch ID does not exist.");
             // Or, alternatively, add a custom attribute to the model
             model.addAttribute("batchIdExistsError", true);
             // Redirect back to the form with the error
         } if (result.hasErrors()) {
           return "update_courseplan";
         }
        cps.updateCourseplan(courseplan);
        
        return "redirect:/courseplans";
    }
    
    @GetMapping("/courseplan/fillup/{planId}")
    public String fillUpCourseplan(@PathVariable("planId") int planId, Model model) {
        cps.updateCourseplanStatus(planId, "Completed");
        return "redirect:/fillup";
    }

    @GetMapping("/fillup")
    public String showFillupCourseplanPage(Model model) {
        List<Courseplan> courseplan = cps.displayfillCourseplan(new Courseplan());
        model.addAttribute("courseplan", courseplan);
        return "fill_courseplan";
    }


    @GetMapping("/courseplan/delete/{planId}")
    public String deleteCourseplan(@PathVariable("planId") int id) {
        cps.deleteCourseplan(id);
        return "redirect:/courseplans";
    }
}
