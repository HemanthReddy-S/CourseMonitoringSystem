package com.coursems.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("/admin_home")
    public String adminHome() {
        return "admin_home"; // This refers to the admin_home.html Thymeleaf template
    }


@GetMapping("/faculty_home")
public String facultyHome() {
    return "faculty_home"; // This refers to the faculty_home.html Thymeleaf template
}
}