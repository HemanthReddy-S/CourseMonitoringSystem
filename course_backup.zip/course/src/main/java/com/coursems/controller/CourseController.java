package com.coursems.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.coursems.model.Course;
import com.coursems.service.CourseService;

import jakarta.validation.Valid;

@Controller
public class CourseController {
	
	@Autowired
	private CourseService csr;
	
	
	
	@PostMapping("/courses")
	public String saveCourses(@Valid Course course, BindingResult result, Model model) {
	    System.out.println("Inside save course");
	    
	    // Check if the course name already exists
	    if (csr.courseNameExists(course.getCourseName())) {
	        // Add an error to the model
	        model.addAttribute("errorMessage", "Course name already exists");
	        return "create_course"; // Return the form view to display the error
	    }
	    
	    // If there are no errors, save the course and redirect to the courses list
	    csr.saveCourse(course);
	    return "redirect:/courses";
	}

	
	@GetMapping("/courses")
	public String listCourses(Course course, Model model) {
		System.out.println("Inside show courses");
		model.addAttribute("courses",csr.displayCourses(course));
		return "courses";
	}
	@GetMapping("course/new")
	public String showCreateForm(Model model) {
		Course course = new Course();
		model.addAttribute("course", course);
		return "create_course";
	}
	
	@GetMapping("/course/{courseId}")
	public String showUpdateForm(@PathVariable("courseId") int id, Model model) {
	    Course course = csr.find(id);
	    model.addAttribute("course", course);
	    return "update_course";
	}

	@PostMapping("courses/update")
	public String updateCourse(@Valid Course course) {
	    csr.updateCsr(course);
	    return "redirect:/courses";
	}

	@GetMapping("/course/delete/{courseId}")
	public String deleteCourse(@PathVariable("courseId") int id) {
	    csr.deleteCourse(id);
	    return "redirect:/courses";
	}


	


}
