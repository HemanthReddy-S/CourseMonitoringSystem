package com.coursems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.coursems.model.Faculty;
import com.coursems.repo.FacultyRepo;
import com.coursems.service.FacultyService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@Controller 
public class FacultyController {

		@Autowired
		private FacultyRepo facrep;
		
		@Autowired
		private FacultyService facultyService;


		@PostMapping("/faculties")
		public String saveMember(@Valid Faculty faculty, Model model) {
			System.out.println("Inside facultyCtlr save faculty");
			facultyService.saveFaculty(faculty);
			return "redirect:/faculties";
		}

		@GetMapping("/faculties")
		public String listFaculties(Model model) {
		    model.addAttribute("faculties", facrep.findAll());
		    System.out.println(facrep.findAll());
		    return "faculties";
		}
		@GetMapping("/faculty/new")
		public String showCreateForm(Model model) {
			Faculty faculty = new Faculty();
			model.addAttribute("faculty", faculty);
			return "create_faculty";
		}

		
		@GetMapping("/updatepassword")
		public String updateCreateForm(Model model) {
			return "updatepassword";
		}
		
		
		
		@GetMapping("/faculty/{facultyId}")
		public String showUpdateForm(@PathVariable("facultyId") int id, Model model) {
			Faculty faculty = facrep.findById(id).get();
			model.addAttribute("faculty", faculty);
			return "update_faculty";
		}
		@PostMapping("faculties/update")
		public String updateFaculty(@Valid Faculty faculty) {
			facrep.save(faculty);
			return "redirect:/faculties";
		}
		
		@GetMapping("/login")
		public String loginForm(@Valid Model model) {
		    System.out.println("Inside login form");
		    model.addAttribute("faculty", new Faculty());
		    return "main_login";
		}
		
		
		@GetMapping("/faculty/delete/{facultyId}")
		public String deleteFaculty(@PathVariable("facultyId") int id) {
			facultyService.deleteFacultyInfo(id);
		    return "redirect:/faculties";
		}
		
//		@PostMapping("/login")
//		public String loginSubmit(@Valid @ModelAttribute Faculty faculty, BindingResult bindingResult) {
//		    System.out.println("Inside post login");
//		    boolean success = facultyService.login(faculty);
//		    String res = "";
//		    if (bindingResult.hasErrors()) {
//		        System.out.println(bindingResult);
//		        res = "main_login";
//		    } else if (success) {
//		        res = "redirect:/admin_home";
//		    } else {
//		        res = "redirect:/login";
//		    }
//		    return res;
//		}
		
//		@PostMapping("/login")
//		public String loginSubmit(@Valid @ModelAttribute Faculty faculty, BindingResult bindingResult, Model model) {
//		    System.out.println("Inside post login");
//		    boolean success = facultyService.login(faculty);
//		    String res = "";
//		    if (bindingResult.hasErrors()) {
//		        System.out.println(bindingResult);
//		        res = "main_login";
//		    } else if (success) {
//		        // Assuming facultyService.login(faculty) returns the logged-in Faculty object
//		        Faculty loggedInFaculty = facultyService.faculty(faculty);
//		        if (loggedInFaculty.isAdmin()) {
//		            res = "redirect:/admin_home";
//		        } else {
//		            res = "redirect:/faculty_home";
//		        }
//		    } else {
//		        // Check for hardcoded admin login
//		        if ("admin".equals(faculty.getUsername()) && "Admin@123".equals(faculty.getPassword())) {
//		            // Assuming you have a way to set the logged-in user as an admin
//		            // This is a placeholder. You should replace this with actual logic to set the user as an admin.
//		            Faculty adminFaculty = new Faculty();
//		            adminFaculty.setAdmin(true); // Assuming setAdmin is a method to mark a user as admin
//		            // Redirect to admin_home
//		            res = "redirect:/admin_home";
//		        } else {
//		            // If the login attempt was not successful and it's not the hardcoded admin login,
//		            // you might want to add a message to the model to inform the user about the failed login attempt.
//		            model.addAttribute("error", "Invalid username or password.");
//		            res = "main_login";
//		        }
//		    }
//		    return res;
//		}
//		
		@PostMapping("/login")
		public String loginSubmit(@Valid @ModelAttribute Faculty faculty, BindingResult bindingResult, HttpServletRequest request, Model model) {
		    System.out.println("Inside post login");
		    boolean success = facultyService.login(faculty);
		    String res = "";
		    if (bindingResult.hasErrors()) {
		        System.out.println(bindingResult);
		        res = "main_login";
		    } else if (success) {
		        // Assuming facultyService.login(faculty) returns the logged-in Faculty object
		        Faculty loggedInFaculty = facultyService.faculty(faculty);
		        // Set the currentFaculty attribute in the session
		        request.getSession().setAttribute("currentFaculty", loggedInFaculty.getFacultyId());
		        if (loggedInFaculty.isAdmin()) {
		            res = "redirect:/admin_home";
		        } else {
		            res = "redirect:/faculty_home";
		        }
		    } else {
		        // Check for hardcoded admin login
		        if ("admin".equals(faculty.getUsername()) && "Admin@123".equals(faculty.getPassword())) {
		            // Assuming you have a way to set the logged-in user as an admin
		            // This is a placeholder. You should replace this with actual logic to set the user as an admin.
		            Faculty adminFaculty = new Faculty();
		            adminFaculty.setAdmin(true); // Assuming setAdmin is a method to mark a user as admin
		            // Redirect to admin_home
		            res = "redirect:/admin_home";
		        } else {
		            // If the login attempt was not successful and it's not the hardcoded admin login,
		            // you might want to add a message to the model to inform the user about the failed login attempt.
		            model.addAttribute("error", "Invalid username or password.");
		            res = "main_login";
		        }
		    }
		    return res;
		}


 
		@GetMapping("/checkId") ///FOR AJAX
		 @ResponseBody
		 public String checkId(@RequestParam int id) {
			System.out.println("inside checkid");
		 if (facultyService.findbyid(id)) {
				System.out.println("inmside exist id");

		  return "exists";
		 } else if (id == 0) {
		  return "zero";
		 } else {
		  return "not exists";

		 }
		}

		
		
		

		// Placeholder method to simulate getting the logged-in faculty's ID
				private int getLoggedInFacultyId() {
				    // Implement logic to get the logged-in faculty's ID
				    // This is a placeholder implementation. You should replace this with actual logic to get the logged-in faculty's ID.
				    return 1; // Example ID
				}

				@PostMapping("/updatePassword")
				public String updatePassword(@RequestParam("oldPassword") String oldPassword,
				                             @RequestParam("newPassword") String newPassword,
				                             @RequestParam("reEnterPassword") String reEnterPassword,
				                             @RequestParam("id") int id,
				                             Model model, RedirectAttributes redirectAttributes) {
				    // Assuming you have a way to get the logged-in faculty's ID
				    Faculty faculty = facultyService.find(id);

				    // Check if the faculty exists
				    if (faculty == null) {
				        model.addAttribute("error", "Faculty ID does not exist.");
				        return "updatepassword"; // Redirect back to the update password form
				    }

				    // Check if the new password matches the re-entered password
				    else  if (!newPassword.equals(reEnterPassword)) {
				        model.addAttribute("error", "New password and re-entered password do not match.");
				        return "updatepassword"; // Redirect back to the update password form
				    }

				    // Check if the old password matches the current password
				    else if (!faculty.getPassword().equals(oldPassword)) {
				        model.addAttribute("error", "Old password is incorrect.");
				        return "updatepassword"; // Redirect back to the update password form
				    }

				    // Update the password
				    faculty.setPassword(newPassword);
				    facultyService.updateFaculty(faculty);

				    redirectAttributes.addFlashAttribute("message", "Password updated successfully");
				    return "redirect:/faculty_home"; // Redirect back to the update password form with a success message
				}

	
//				@GetMapping("/myprofile")
//				public String displayFacultyAccount(HttpServletRequest request, Model model) {
//				    int currentFacultyId = (int) request.getSession().getAttribute("currentFaculty");
//				    Faculty faculty = facultyService.fetchFacultyDetail(currentFacultyId);
//				    model.addAttribute("faculty", faculty);
//				    return "myprofile";
//				}
				
				 @GetMapping("/myprofile")
				    public String displayFacultyAccount(HttpServletRequest request, Model model) {
				        Integer currentFacultyId = (Integer) request.getSession().getAttribute("currentFaculty");
				        if (currentFacultyId != null) {
				            Faculty faculty = facultyService.fetchFacultyDetail(currentFacultyId);
				            model.addAttribute("faculty", faculty);
				        } else {
				            // Handle the case where "currentFaculty" attribute doesn't exist in the session
				            // You might want to redirect the user, throw an exception, show an error message, etc.
				        }
				        return "myprofile";
				    }
				


		
	}


