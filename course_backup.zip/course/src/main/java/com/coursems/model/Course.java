package com.coursems.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Course {
	@Id
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int courseId;
	
	
	@Column
	private String courseName;
	
	@Column
	private int fee;
	
	@Column
	private String courseDescription;
	
	

	    // Getters and setters for courseId
	    public int getCourseId() {
	        return courseId;
	    }

	    public void setCourseId(int courseId) {
	        this.courseId = courseId;
	    }

	    // Getters and setters for courseName
	    public String getCourseName() {
	        return courseName;
	    }

	    public void setCourseName(String courseName) {
	        this.courseName = courseName;
	    }

	    // Getters and setters for fee
	    public int getFee() {
	        return fee;
	    }

	    public void setFee(int fee) {
	        this.fee = fee;
	    }

	    // Getters and setters for courseDescription
	    public String getCourseDescription() {
	        return courseDescription;
	    }

	    public void setCourseDescription(String courseDescription) {
	        this.courseDescription = courseDescription;
	    }
	


	public Course() {
		
	}

}
