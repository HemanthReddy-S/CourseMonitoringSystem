package com.coursems.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
public class Faculty {

	@Id
	@Column 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int facultyId;
	
	@Column 
	private String facultyName;
	@Column 
	private String facultyAddress;
	@Column 
	private String mobile;
	@Column 
	private String email;
	@Column 
	@NotBlank(message="Username cannot be blank")
	private String username;
	@Column 
	@NotBlank(message="Password cannot be blank")

	private String password;

	@Column 
	   private String role; // Add this line to include a role field

	 

	    // Existing getters and setters...
	


	public Faculty() {
		super();
	}

	public int getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}

	public String getFacultyName() {
		return facultyName;
	}

	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}

	public String getFacultyAddress() {
		return facultyAddress;
	}

	public void setFacultyAddress(String facultyAddress) {
		this.facultyAddress = facultyAddress;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	  
    // Getters and setters for the new role field
    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

	public boolean isAdmin() {
		// TODO Auto-generated method stub
		return false;
	}

	public void setAdmin(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
