package com.coursems.service;



import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.coursems.model.Batch;

import jakarta.validation.Valid;

@Service
public interface BatchService {

    void saveBatch(@Valid Batch batch);

    void deleteBatch(int id);

    Batch find(int id);

    void updateBatch(@Validated Batch batch);

    List<Batch> displayBatches(Batch batch);

	boolean existsByName(String batchName);
}

