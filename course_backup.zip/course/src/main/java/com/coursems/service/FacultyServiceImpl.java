package com.coursems.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.coursems.model.Faculty;
import com.coursems.repo.FacultyRepo;

import jakarta.validation.Valid;

@Service
public class FacultyServiceImpl implements FacultyService {

    @Autowired
    private FacultyRepo facrep;

    @Override
    public void saveFaculty(@Valid Faculty faculty) {
        facrep.save(faculty);
    }

   @Override
    public Faculty find(int id) {
        Faculty faculty = facrep.findById(id).get();
        return faculty;
    }

    @Override
    public void updateFaculty(@Valid Faculty faculty) {
        facrep.save(faculty);
    }

    @Override
    public List<Faculty> displayFaculties(Faculty faculty) {
        List<Faculty> list = new ArrayList<>();
        list.addAll(facrep.findAll());
        return list;
    }

	@Override
	public void deleteFacultyInfo(int id) {
		facrep.deleteById(id);
		
	}
	
	   
	    	

	@Override
	public boolean existsById(int facultyId) {
		return facrep.existsById(facultyId);
	}


	  @Override
	    public boolean login(Faculty faculty) {
	        Optional<Faculty> facultyOptional = facrep.findByUsername(faculty.getUsername());
	        if (facultyOptional.isPresent()) {
	            Faculty existingFaculty = facultyOptional.get();
	            // Assuming you have a method to check if the provided password matches the stored password
	            // This is a placeholder. You should replace this with actual logic to compare passwords.
	            return existingFaculty.getPassword().equals(faculty.getPassword());
	        } else {
	            return false;
	        }
	    }

	    @Override
	    public Faculty faculty(Faculty faculty) {
	        Optional<Faculty> facultyOptional = facrep.findByUsername(faculty.getUsername());
	        if (facultyOptional.isPresent()) {
	            return facultyOptional.get();
	        } else {
	            return null; // or throw an exception
	        }
	    }

		@Override
		public Faculty findByUsername(String username) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean findbyid(int id) {
			System.out.println("inmside service");

			  if(facrep.findById(id).get()!=null) {
				  return true;
			  }
			return false;
		}

		@Override
	    public Faculty fetchFacultyDetail(int currentFacultyId) {
	        Optional<Faculty> facultyOptional = facrep.findById(currentFacultyId);
	        if (facultyOptional.isPresent()) {
	            return facultyOptional.get();
	        } else {
	            return null; // or throw an exception
	        }
	    }
	
	}
