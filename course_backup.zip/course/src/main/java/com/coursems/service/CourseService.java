package com.coursems.service;



import java.util.List;

import org.springframework.stereotype.Service;

import com.coursems.model.Course;

import jakarta.validation.Valid;

@Service
public interface CourseService {

	void saveCourse(Course course);

	void deleteCourse(int id);

	Course find(int id);

	void updateCsr(@Valid Course course);

	List<Course> displayCourses(Course course);

	boolean existsById(int courseId);

	boolean courseNameExists(String courseName);

}

