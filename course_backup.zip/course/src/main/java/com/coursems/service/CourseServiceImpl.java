	package com.coursems.service;
	
	import java.util.ArrayList;
	import java.util.List;
	
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
	
	import com.coursems.model.Course;
	import com.coursems.repo.CourseRepo;
	
	import jakarta.validation.Valid;
	
	@Service
	
	public class CourseServiceImpl implements CourseService {
	
		@Autowired
		private CourseRepo csrrep;
		
	
		@Override
		public void saveCourse(Course course) {
			csrrep.save(course);
	
		}
	
		@Override
		public void deleteCourse(int id) {
			csrrep.deleteById(id);
	
		}
	
		@Override
		public Course find(int id) {
			Course course = csrrep.findById(id).get();
			return course;
		}
	
		@Override
		public void updateCsr(@Valid Course course) {
			csrrep.save(course);
	
		}
	
		@Override
		public List<Course> displayCourses(Course course) {
			List<Course> list = new ArrayList<>();
			list.addAll(csrrep.findAll());
			return list;
		}
		
		
		    public CourseServiceImpl(CourseRepo csrrep) {
		        this.csrrep = csrrep;
		    }


		@Override
		public boolean existsById(int courseId) {
			return csrrep.existsById(courseId);
		}
		
		public boolean courseNameExists(String courseName) {
		    // Implement the logic to check if a course with the given name exists
		    // This is a placeholder implementation. You need to replace it with your actual logic.
		    return csrrep.existsByCourseName(courseName);
		}

	
	}
