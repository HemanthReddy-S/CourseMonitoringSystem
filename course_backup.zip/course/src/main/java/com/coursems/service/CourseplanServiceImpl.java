package com.coursems.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coursems.model.Courseplan;
import com.coursems.repo.CourseplanRepo;

import jakarta.validation.Valid;

@Service
public class CourseplanServiceImpl implements CourseplanService {

    @Autowired
    private CourseplanRepo courseplanRepo;

    @Override
    public void saveCourseplan(@Valid Courseplan courseplan) {
        // Set the status to "Pending" before saving
        courseplan.setStatus("Pending");
        courseplanRepo.save(courseplan);
    }


    @Override
    public void deleteCourseplan(int planId) {
        courseplanRepo.deleteById(planId);
    }

    @Override
    public Courseplan find(int planId) {
        Courseplan courseplan = courseplanRepo.findById(planId).get();
        return courseplan;
    }

    @Override
    public void updateCourseplan(@Valid Courseplan courseplan) {
    	 courseplan.setStatus("Pending");
        courseplanRepo.save(courseplan);
    }


	@Override
	public List<Courseplan> displayCourseplan(Courseplan courseplan) {
		  List<Courseplan> list = new ArrayList<>();
	        list.addAll(courseplanRepo.findAll());
	        return list;
	}
	
	
	
	public boolean checkIfBatchIdExists(int batchId) {
        return courseplanRepo.existsByBatchId(batchId);
    }


	@Override
	public void updateCourseplanStatus(int planId, String status) {
		 // Fetch the course plan by its ID
        Courseplan courseplan = courseplanRepo.findById(planId)
                .orElseThrow(() -> new IllegalArgumentException("Course plan not found with id " + planId));

        // Update the status of the course plan
        courseplan.setStatus(status);

        // Save the updated course plan back to the database
        courseplanRepo.save(courseplan);
    }
		
	
	
	public List<Courseplan> displayfillCourseplan(Courseplan courseplan) {
	    // Assuming you have a repository or DAO layer to fetch course plans
	    return courseplanRepo.findAll();
	}

	
}

