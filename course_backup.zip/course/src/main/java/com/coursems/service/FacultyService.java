package com.coursems.service;



import java.util.List;

import org.springframework.stereotype.Service;

import com.coursems.model.Faculty;

import jakarta.validation.Valid;

@Service
public interface FacultyService {

	 void saveFaculty(@Valid Faculty faculty);

	    void deleteFacultyInfo(int id);

	    Faculty find(int id);

	   boolean findbyid(int id); 
	    void updateFaculty(@Valid Faculty faculty);

	    List<Faculty> displayFaculties(Faculty faculty);

		boolean existsById(int facultyId);

		boolean login(Faculty faculty);
		Faculty faculty(Faculty faculty);
		Faculty findByUsername(String username);

		Faculty fetchFacultyDetail(int currentFacultyId);
		
}


