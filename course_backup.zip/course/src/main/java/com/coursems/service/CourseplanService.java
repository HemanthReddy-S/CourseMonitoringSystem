package com.coursems.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.coursems.model.Courseplan;

import jakarta.validation.Valid;

@Service
public interface CourseplanService {

    void saveCourseplan(@Valid Courseplan courseplan);

    void deleteCourseplan(int id);

    Courseplan find(int id);

    void updateCourseplan(@Valid Courseplan courseplan);

    List<Courseplan> displayCourseplan(Courseplan courseplan);
    
    boolean checkIfBatchIdExists(int batchId);

	void updateCourseplanStatus(int planId, String string);

List<Courseplan> displayfillCourseplan(Courseplan courseplan);
    
}
