package com.coursems.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coursems.model.Batch;
import com.coursems.repo.BatchRepo;

import jakarta.validation.Valid;

@Service
public class BatchServiceImpl implements BatchService {

    @Autowired
    private BatchRepo batchRepo;

    @Override
    public void saveBatch(@Valid Batch batch) {
        batchRepo.save(batch);
    }

    @Override
    public void deleteBatch(int id) {
        batchRepo.deleteById(id);
    }

    @Override
    public Batch find(int id) {
        Batch batch = batchRepo.findById(id).get();
        return batch;
    }

    @Override
    public void updateBatch(@Valid Batch batch) {
        batchRepo.save(batch);
    }
    
    public boolean existsByName(String batchName) {
    	
        return batchRepo.existsByBatchName(batchName);
    }

    @Override
    public List<Batch> displayBatches(Batch batch) {
        List<Batch> list = new ArrayList<>();
        list.addAll(batchRepo.findAll());
        return list;
    }
    
}
